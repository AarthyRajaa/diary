<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>
            Send Email
        </title>
    </head>
    <body>
        <form class="" action="send.php" method="post">
            Email<input type="email" name="email" value=""><br>
            Subject<input type="text" name="subject" value=""><br>
            Messege<input type="text" name="messege" value=""><br>
            <button type="submit" name="send">Send</button>

        </form>
    </body>
</html>